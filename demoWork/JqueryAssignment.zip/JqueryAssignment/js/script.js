var str1, strImg;
$(document).ready(function()  {
 $("#find").click(function()  { //Movie find function
  //$(".para").empty();
 // var $orders=$('#para1');
  var  $tableClass=$('#tableClass');
  var title = $("#srch-term").val();
  $.ajax({
           type: 'GET',
           url: 'http://www.omdbapi.com/?s=' + title,
           //dataType: "json",
           success: function(details) {
               console.log(details);
               var Search=details.Search;
               //$.each(details, function(i, detail) {
                   console.log(Search);
                   $.each(Search, function(j, data) {
                       console.log(data.Title);
                       $tableClass.append('<table><tr> <th>Title:' + data.Title + "</th></tr><tr><th>Year:" + data.Year +
                           "</th></tr><tr><th>Released:" + data.Released + "</th></tr><tr><th> Director:" + data.Director +
                           "</th></tr><tr><th> Actors:" + data.Actors + "</th></tr><tr><th><img src=" + data.Poster + "</th></tr></table>");
                   });
               //});
           }
       });
//   $.ajax({
//     type:'GET',
//     url:'http://www.omdbapi.com/?s=' + title,
//      dataType: "json",
//     success:function(data){
//       console.lo
//         $.each(data, function(i, order){
//           $.each(order, function(i,content){
//             $tableClass.append('<tr> <td>Title:' + content.Title + "</td></tr><tr><td>Year:" + content.Year +
//              "</td></tr><tr><td>Released:" + content.Released + "</td></tr><tr><td> Director:" + content.Director +
//              "</td></tr><tr><td> Actors:" + content.Actors + "</td></tr><tr><td><img src=" + content.Poster + "</td></tr>");
//           });

//         });
//       }
// });
  // $.get("http://www.omdbapi.com/", {s: title}, function(data, status){
  //   if(status == "success" && data.Response!="False"){
  //     $('#successAlert').slideDown();
  //    // str1 = JSON.stringify(data);
  //   // //  alert(str1);
  //   //   var index1 = str1.search("http");
  //   //   var index2 = str1.search("jpg");
  //   //   strImg = str1.substring(index1,index2+3);
  //   //   var title, year,imdbID,MovieType;
  //   //  title=data.Search[0].Title;
  //   //  alert(title);
  //   var tableClass= $('tableClass');
  //   console.log(tableClass);
  //     //  $('tableClass').append(str);
  //    var lengths=data.Search.length;
  //    console.log(length);
  //    for (var i = 0; i < lengths; i++) 
  //     { 
  //       tableClass.append("<tr><td>" + "Title :" + "</td>" +"<td>" + data.Search[i].Title + "</td></tr>" );
  //     }


  // //    $(".para").append(str1);
  //  //   $("img.image").attr("src", strImg);
  //     $('#featuresHeading').slideDown();
  //     $('#features').slideDown();
  //     window.setTimeout(function() {
  //       $("#successAlert").fadeTo(500, 0).slideUp(500, function(){
  //         $(this).remove(); 
  //       });
  //     }, 2000); 
  //   }else
  //   { // Fail Operation
  //    $('#FailAlert').slideDown();
  //    $("#featuresHeading").css("display", "none");
  //    $("#features").css("display", "none");
  //    window.setTimeout(function() {
  //     $("#FailAlert").fadeTo(500, 0).slideUp(500, function(){
  //       $(this).remove(); 
  //     });
  //   }, 2000); 

  //  }
  //    }); //get function ends here 

   });  //click function ends



 }); //ready function ends